﻿/// <summary>
/// SEE.Layout contains code of node and edge layouts. Code contained
/// therein must not depend on SEE.DataModel, SEE.GameObjects or
/// SEE.GO. Is should be able to serve as a general layout library
/// outside of SEE.
/// </summary>
namespace SEE.Layout
{
}
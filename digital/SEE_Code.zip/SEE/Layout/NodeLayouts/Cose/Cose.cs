﻿/// <summary>
/// SEE.Layout.NodeLayouts.Cose provides a composite layout and
/// force-directed layouts. A composite layout is a layout
/// where one specify another layout for particular subtrees
/// of the node hierarchy.
/// </summary>
namespace SEE.Layout.NodeLayouts.Cose
{
}
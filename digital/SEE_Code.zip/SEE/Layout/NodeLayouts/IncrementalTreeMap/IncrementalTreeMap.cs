/// <summary>
/// SEE.Layout.NodeLayouts.IncrementalTreeMap contains code that represents
/// implementation details of the incremental tree map layout.
/// </summary>
namespace SEE.Layout.NodeLayouts.IncrementalTreeMap
{
}

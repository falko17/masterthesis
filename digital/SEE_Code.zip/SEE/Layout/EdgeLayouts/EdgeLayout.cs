﻿/// <summary>
/// SEE.Layout.EdgeLayout contains code for laying out edges.
/// </summary>
namespace SEE.Layout.EdgeLayouts
{
}

﻿/// <summary>
/// Input/output of layout information.
/// </summary>
namespace SEE.Layout.IO
{
}
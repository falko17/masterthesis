﻿/// <summary>
/// SEE.CameraPaths contains code for recording and replaying camera paths.
/// </summary>
namespace SEE.CameraPaths
{
}
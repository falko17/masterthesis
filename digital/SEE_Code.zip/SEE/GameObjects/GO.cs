﻿/// <summary>
/// SEE.GO (GO for GameObjects) contains factories that create game objects
/// to be shown in the scene. These factories may be used at
/// design time (in the Unity editor) as well as run time
/// (during the game).
/// </summary>
namespace SEE.GO
{
}
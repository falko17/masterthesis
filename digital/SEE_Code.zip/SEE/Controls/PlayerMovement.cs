﻿using UnityEngine;

namespace SEE.Controls
{
    /// <summary>
    /// Common abstract superclass of all player movements.
    /// </summary>
    public abstract class PlayerMovement : MonoBehaviour
    {
    }
}

﻿/// <summary>
/// SEE.DataModel.DG.IO provides input/output for persistent storage
/// and retrieval of data structures in SEE.DataModel.DG.
/// </summary>
namespace SEE.DataModel.DG.IO
{
}
﻿/// <summary>
/// SEE.DataModel contains code that manages the underlying data model
/// for the dependency graph (DG).
/// </summary>
namespace SEE.DataModel.DG
{
}
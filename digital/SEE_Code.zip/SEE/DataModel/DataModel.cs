﻿/// <summary>
/// SEE.DataModel contains code that manages the underlying data model of the
/// visualized scenes. In particular, it provides the data structures for the
/// dependency graph.
/// </summary>
namespace SEE.DataModel
{
}
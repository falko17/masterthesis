﻿/// <summary>
/// Input/output of data structures for showing runtime information by way of
/// animated graphs.
/// </summary>
namespace SEE.DataModel.Runtime.IO
{
}